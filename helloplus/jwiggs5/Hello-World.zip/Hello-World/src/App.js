function App() {
  return (
    <>
      <h1>Hello World!</h1>
      <h2>-By Jerf : )</h2>
      <a href= "https://github.com/utk-cs340-fall25/FocusFlowTracker/tree/main/helloplus/jwiggs5">This is where you came from.</a>
      <img src = "https://vignette.wikia.nocookie.net/fantendo/images/8/86/Kirby_KSSU.png/revision/latest?cb=20110810163711" alt = "" />
    </>
  );
}

export default App;